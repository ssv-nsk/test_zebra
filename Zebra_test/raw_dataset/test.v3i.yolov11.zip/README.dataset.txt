# test > 2025-06-29 8:14am
https://universe.roboflow.com/ssv273-mail-ru/test-8nd0p

Provided by a Roboflow user
License: CC BY 4.0

