# test > 2025-07-02 3:58pm
https://universe.roboflow.com/ssv273-mail-ru/test-8nd0p

Provided by a Roboflow user
License: CC BY 4.0

